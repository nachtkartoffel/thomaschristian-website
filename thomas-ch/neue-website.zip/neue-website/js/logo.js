/* Logo auf der Stage: Porträt im Kreis – blinzelt unregelmäßig, bewegt sich leicht (Grundbewegung)
   und zeigt bei Klick auf die Seite zufällig einen von fünf Gesichtsausdrücken.
   Einbinden: <div data-logo></div> – das SVG wird hier hineingesetzt. */
(() => {
  /* Illustration aus assets/index.svg – unverändert bis auf: Klassen für die Animation, schwarzer Kreis-Stroke, Zusatzformen (Tränen, Schweiß, Konturbrücke) */
  const SVG = `<svg aria-hidden="true" focusable="false" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" viewBox="0 0 1065.5 1108.4">
  <!-- Generator: Adobe Illustrator 30.5.1, SVG Export Plug-In . SVG Version: 2.1.4 Build 3)  -->
  <defs>
    <style>
      .st0 {
        fill: none;
        stroke: #000;
        stroke-miterlimit: 10;
        stroke-width: 19px;
      }

      .st1 {
        clip-path: url(#logoClip);
      }
    </style>
    <clipPath id="logoClip">
      <circle class="st0" cx="532.8" cy="532.8" r="523.3"/>
    </clipPath>
  </defs>
  <g class="st1">
    <g>
      <path d="M580.8,328.5c12,54.5,31.3,58.6,31.3,58.6,0,0,6.3,24.3,3.8,62.6,17.3-3.4,10.8-32.3,7.5-51.7-2.1-12-5.6-26.1-6.5-26.7-2.2-1.6-20-10.4-36-42.8Z"/>
      <path d="M635,444c-1.5,1.9-2.1,6.5-2.1,6.5,0,0-9.9-1.4-17.1-.7,1-4.1.8-7.1.8-7.1,0,0,15,.4,18.3,1.3Z"/>
      <path d="M653,506.9c38.3,20.9,86.2-13.3,84-58.3-2.2-43.6-55.1-83.4-104,1.8-6.9-1.4,3.5-15.4,7.3-22.4,12.3-22,37.6-37.7,60.2-35.7,29.8,2.7,46.5,34.2,46.1,59-1.4,78.9-94.1,83.1-93.5,55.5Z"/>
      <path d="M671.9,444.4c29.7-9.6,32.8,6.1,30,18.3-3.7,16-18.4,17.2-25.7,13.2-3.9-2.1-5-6-6.5-5.4s.4,8.2,6,11c9.8,5,28,3.3,32.7-18.1,5.5-25-16.6-37-36.5-19Z"/>
      <path d="M579.8,267.9c-1,1-1.9,2-2.9,3-.6.6-1.2,1.1-1.8,1.5,2.2,37.8,40.6,66.6,58.8,75-29.6-26.4-46.6-56.7-54.2-79.6Z"/>
      <path class="brow brow--r" d="M418.3,358.1c-.5,3.9.7,7,2.2,9.3s5.9,4.3,9.4,3c0,0,38.9-33.5,67.9-33s28.2,1.5,38.5,20.6c-5-10.8-9.1-26.9-33.6-29.3s-23.1-.1-40,6.5-38.9,26.9-44.3,22.8Z"/>
      <path d="M603.1,224.1c1.5,29.2-24,43.5-29.5,45.9,15.9-19.3,12.5-36.4,8.4-40.7-21.9,24-65.1,40.6-82.4,50.9,15.6-15.7,25.3-27.1,29.8-36.4-17.6,17.9-47.6,31.9-73.9,38.2-17.3,4.2-32.9,5.2-42.2,5.4-6.4.1-12.8,1.6-18.7,4.3-5.7,2.6-13.6,6.3-23.1,10.9,85.8-1.8,102.7-18,112.1-21.1-3.1,6.8-8.6,15.3-19,22.9,27.5-7.3,93.7-41.3,101.6-48.4-3.8,16.7-7.2,22.8-12.6,30.7,28.9-7.9,65.5-37.7,49.5-62.6Z"/>
      <path d="M257,330.5c13.7,20.4,68.3,22.9,110.7,11.2,34.5-9.5,60.7-29.6,69.8-49.3l-10.7-3.4s-9,31.9-70.7,42.8c-64.6,11.4-99.1-1.3-99.1-1.3Z"/>
      <path class="lid lid--r" d="M528.3,404.1c-10.6-32.6-26.4-56.2-80.4-21-1.2.8-2.9.4-3.7-.8h0c-.7-1.2-.5-2.7.7-3.5,7.7-5.7,36.7-25.1,58.6-16.8,25.4,9.7,24.8,42.1,24.8,42.1Z"/>
      <path class="lowlid lowlid--r" d="M447,478.6h0c0-.9.5-1.7,1.3-2.1,19.7-10.9,51.3-9.8,67.1,4.4s1,2.4.1,3.3h0c-.8.8-1.9.9-2.9.4-3.8-2.3-14.6-7.7-31.2-8.6-14.5-.8-25.4,2.8-30.8,5.1s-3.6-.6-3.6-2.4Z"/>
      <path class="eye eye--r pupil" d="M503.7,473.7c2.3-5.4,4.2-11.6,5.5-18.4l-17.5-13.2,19.8-11c.2-35.9-13.7-65.1-30.9-65.2-17.3,0-31.4,29-31.5,64.9,0,16,2.7,30.7,7.2,42.1,14.8-5.2,33.4-5.1,47.4.8Z"/>
      <path class="eye eye--l pupil" d="M381.6,469.6c.8-4.2,1.4-8.9,1.7-13.8l-14.3-9.5,14.1-7c-.1-1.7-.3-3.4-.5-5.1-3.2-30.4-15.2-54-26.7-52.8-11.5,1.2-18.2,26.8-14.9,57.2,1.5,14.4,5,27.3,9.5,36.8,10.4-4.4,21-6.1,31.1-5.8Z"/>
      <path class="lowlid lowlid--l" d="M380.6,473.9c.4-1.4.7-2.8,1-4.3-12.1-.4-25.1,2.1-37.4,8.9-1.5.8-2.1,2.2-1.6,3.8.2.8,1.1,1.1,1.8.8,12.4-6,24.6-9.7,36.3-9.1Z"/>
      <ellipse cx="391.2" cy="501.7" rx="21.7" ry="46.4" transform="translate(-113.1 889.5) rotate(-89.6)"/>
      <path d="M287.8,294.7s-1.4,33.8-30.8,35.8c25.6,16.3,46.9-21.4,47.5-34.6l-16.7-1.2Z"/>
      <path d="M367.9,203.8c22.4,38.4,65.3,43,75.3,43.6-4.2,4.2-9.6,10-33.8,20.9,37.8-12.3,61.7-26.7,74.7-44.9-38,20-99.3,1.2-116.2-19.6Z"/>
      <path d="M460.8,779.1c-2.2-2.1-5-3.8-6.1-4.4s-2.6-.4-3.6.4c-3.4,2.9-12.1,11.1-13.1,20.9-1.2,12.1,8.5,32.5,13.8,43.4,0,0,16.3,30.7,22,68.5-29.6-90.3-38.7-78.6-41.5-101.6-1.5-12.6.9-20.3,5.9-25.7-4.8-10.9-15.9-20.8-17.1-23.7s1-8.8,9.3-6.7c4.1,1,11.3,6.4,17.6,13.1s8.9,10.9,12.8,15.7Z"/>
      <path d="M481.2,676.2c2,16.8,8.5,41.1,15.8,66.9l8.7,2.8c-8.7-25.4-8.9-33.9-8.9-33.9,49.9-8,161.2-101.5,167.9-141.7,2.7-8.3-5.9-11.4-5.9-11.4,0,0-7.2,32.8-31.7,52.9-43.5,35.6-74.4,52.9-145.9,64.4Z"/>
      <path d="M397.2,665.9c15.6,11.1,63.7,12.9,84,10.3s42.7,7.1,2.8,9.9c-39.9,2.7-77.8,0-93.2-12.1-13.5-10.7-30.4-29.9-48-67.3-21.1-44.9-33.8-103.7-11.2-124.1,0,0-2.5-17.1,5.7,2.1-37.5,42.1,38.9,166.2,60,181.3Z"/>
      <path d="M664.7,570.3s-3,83.3-1.9,96.2c0,0-9.1,11.4-10,4.4-1-7,.1-79.8,2.7-89.2,2.6-9.4,9.3-11.5,9.3-11.5Z"/>
      <path d="M672.5,517.6s-3.5,13.9-5.2,28.9c-2.1,18.5-3.6,35.2-4.8,44.3,0,0-6.9,2.1-7.5-1.6-.7-3.7,4.9-61.9,7.7-66.1s9.8-5.4,9.8-5.4Z"/>
      <path d="M562.9,825.3s-3.3-32.6-1.2-39.5c2.4-7.9,25.4-35.4,48.9-61.9s52.2-54.6,52.2-57.3c0-5.1-7.5-.6-7.5-.6,0,0-26.8,26.5-51.5,54.4-23.7,26.9-45.3,55.1-47.8,62.2-4.4,12.5,1.8,49.8,1.8,49.8l5.1-7Z"/>
      <path d="M693.1,517c-.6,6.7-5.4,25.4-7.3,30.9-3.3,9.6-22,14.5-22,14.5l-2.8,9.4s16.9-2,28.3-14.5c11.4-12.5,13.2-43.6,13.2-43.6l-9.4,3.4Z"/>
      <path d="M586.6,806.7c-7.8,3.6-68.4,55.1-79,64.6-10.6,9.5-28.7,48.2-28.7,48.2l2.7,8.1s17.5-40.6,28.2-50.7,75.6-66.9,83.3-67.6l-6.5-2.5Z"/>
      <path d="M225.4,268.4c25.6,46.4,81.1,39.5,151.2,6.8-80.8,21.4-124.1,13.5-151.2-6.8Z"/>
      <path d="M225.3,173.2c52.7,71.7,102.4-5.2,186.5,23.7-100.2-47.5-109.3,36.4-186.5-23.7Z"/>
      <path d="M321.9,235c-34.9,15.2-86.7,8.7-89.2-54.2-3-3.1-7.5-7.6-7.5-7.6-2.1,104.5,84.3,74.3,96.6,61.7Z"/>
      <path d="M321.9,235c-16.5,16.6-74.6,60.9-96.6,33.4,25.4,9.9,52.5-22,52.5-22,0,0,6.8,2.5,23.7-2.7,17-5.2,20.4-8.7,20.4-8.7Z"/>
      <path d="M367.6,152.8c46.4,0,73.2-24.9,99.9-32.2-51.5-3.4-69.6,28.6-99.9,32.2Z"/>
      <path d="M324.1,166.8c-7.9,10.2-26.7,35.5-47,32.9,7.9-16.8,16-22.5,47-32.9Z"/>
      <path d="M501.5,805.3c6.4,26.1,18.9,42,23,51.2l6.5-3.7c-10.8-13-20.6-28-29.6-47.5Z"/>
      <path d="M501.7,759.3c33.3-12.7,105.6-47.4,119.4-56l-3.1,9.5c-23.4,11.4-75.2,42.4-116.3,46.5Z"/>
      <path class="chin" d="M406.1,602.2c5.2,8.6,16.5,6.8,21,2.6.7-.6.3-1.8-.6-1.9l-19.3-2.4c-.9-.1-1.6.9-1.1,1.7Z"/>
      <path class="dimple" d="M469.1,559.5c3.6-.9,8.4,2.6,11.3,7.1,3.3,5.1,4.4,11.5,2.2,11.9s-4.4-6.5-7.9-10.7-9.9-7.2-5.6-8.3Z"/>
      <path class="mouth" d="M389.1,578.3c30.8,4.2,59.9,1,84.1-13.3l4.6,5.3c-25.9,18.5-73,20.7-89.2,9.4-.7-.5-.3-1.5.5-1.4Z"/>
      <path d="M464,683.8s-63.1,53.8-66.8,71.6,7.1,34.9,19.5,54.2c6.9,10.7,14,20.9,18.2,27s3.5,7.8,2.9,12c-2.5,18.2-6.9,77.2,15,196.9l5.2-7.4s-10-71.9-11.3-108.4c-1.3-36.5,4.1-86.4,4.1-86.4,0,0-21.7-32.1-32.7-53.8-9.2-18.1-8.1-26-8.4-30.5-.8-10,34.1-48.6,79.2-77.1l-25,1.9Z"/>
      <path d="M466.4,933c-5.2-.5-9.9,4.1-10.5,10.3s3.2,11.5,8.5,12c5.2.5,9.9-4.1,10.5-10.3s-3.2-11.5-8.5-12ZM464.6,951.4c-3.2-.3-5.5-3.6-5.2-7.5s3.2-6.7,6.5-6.4,5.5,3.6,5.2,7.5-3.2,6.7-6.5,6.4Z"/>
      <path d="M511.6,122.2c59.4,13.6,87.2,43.7,98.1,59.7.5.8,1.7,0,1.3-.8-9.7-18.9-36.5-55.7-99.4-58.9Z"/>
      <path d="M573.7,195c-27.1,8.3-34.7,26-71.7,40.6,20.9-9.3,30.6-41.2,71.7-40.6Z"/>
      <path d="M415.5,131.1c-20.8,11.7-69.2,1.9-83.1,8.5s-29.3,23-31.5,37.3c0,0-3,16.3-10.1,8.4-8.2-19.6,19.2-52.4,44.4-58.6s25,.5,40.9-.1c27.9-1.1,24.5-7.7,69.9-5.2,0,0-14.3.7-30.4,9.8Z"/>
      <path d="M729.4,278.6c8,11.8,26.5,27.9,16.5,87.8-3.2,18.9-14.9,24.5-16.3,30.3-1.4,5.9-3.6,14.9-3.6,14.9,0,0,7.6,17.5,9.4,10,.9-4.2,3.4-10.7,5.4-15.6s3.3-6.8,5.7-9.7c4.4-5.4,12.5-19.1,13.7-47.7,1.8-39.4-11.9-55.4-30.7-70Z"/>
      <path d="M620,218.4c31.7,14,40.4,35.3,70.5,43.9-42.8,7.7-48.4-34-70.5-43.9Z"/>
      <path d="M629.3,200.2c55-3.9,56.1,34.6,74.3,46.4-21.5-24.9-6.3-59.8-74.3-46.4Z"/>
      <path d="M612.1,160.1c-101-113.4-195.4-36.6-195.4-36.6l-23,3.3c50.7-67.8,190.3-47,218.5,33.3Z"/>
      <path d="M650.7,175l11.5-5.2c-16.8-36.7-42.1-50-75.8-47.1l3.6,10.8c21.6-10,60.5,20.2,60.7,41.5Z"/>
      <path d="M722.1,236c-9.8-36.5-34.5-55.8-71.4-61l11.5-5.2c39.3,6.8,61,27.4,71.7,70.2l-11.8-4Z"/>
      <path d="M708.6,231.6c72,39,65.1,96,49.5,105.1-7.4,4.3-1.5,16.3-1.5,16.3,9.9-3.2,22.5-20.2,22.4-40.5,0-33.9-26.9-76.3-70.5-80.9Z"/>
      <path d="M589.3,189.2c-47.1-34.2-42.7,6-150.1-14.8,56.8,5.1,104.3-38.7,150.1,14.8Z"/>
      <path d="M205.3,1041.8c14.2-23.4,35.5-62.3,53.6-104.9,7-16.5,12.9-31.5,18.1-44.8,13.2-33.8,22.7-58.2,38.2-72.2,18.1-16.3,42.7-24.2,71.2-33.4,5.9-1.9,12-3.8,18.2-5.9l-2.9-8.5c-6.2,2.1-12.2,4-18.1,5.9-29.5,9.5-55,17.6-74.5,35.3-17.1,15.5-27,40.7-40.6,75.6-5.1,13.2-11,28.1-17.9,44.5-18.8,44.1-41.6,85-55.4,107.5l10,.9Z"/>
      <path d="M632.9,933.5"/>
      <path d="M624.4,946.1"/>
      <path d="M649.5,908.6"/>
      <path d="M624.4,946.1c-11.7,11.5-24.3,21.5-37.3,30.2-.7,9.4-1.9,18.9-3.4,28.5,13.2-18.5,27-38.5,40.7-58.7Z"/>
      <path d="M488.8,1017.2c10.8-3.3,20.9-6.8,30.5-10.6-.8-11.5-2.5-22.3-5-32.5-9.3,15.8-25.6,43.3-25.5,43.1Z"/>
      <path d="M669.9,710.6c-10.9,18.4-39.1,66.1-38.8,65.7,1.4,3.8,2.7,7.6,3.9,11.4,14.8-8.8,33.3-21,51.9-36.6-4.4-13.6-10-27.2-17.1-40.3,0,0,0,0,0-.1Z"/>
      <path d="M582.8,973.9c.3-4.8.6-9.6.6-14.3.3-16.2-.4-39-4.8-63.4-7.8,3.1-15.6,6.1-23.5,8.8-13,22.1-25.8,43.6-37.6,63.6,3.2,11.2,5.2,23.3,6.2,36.2,23.1-9.4,42.6-20,59.1-31Z"/>
      <path d="M672.5,706.3c7.5,13.5,13.4,27.6,18.1,41.7,9.8-8.5,19.7-18,29-28.4.7,1.5,1.3,3,2,4.5-9.5,10.5-19.4,20-29.4,28.5,6.1,19.3,9.9,38.6,12.2,56.4,10-10.1,19.7-21.3,28.4-33.5,3-4.2,4.4-9.4,4-14.5,0-.9-.2-1.6-.4-2.1-3.3-8.1-10-24.1-17.1-40.3-9.6-22-21.5-43.9-25.9-51.4s-1.6-.5-1.6.4c-.1,4.8-.4,6.7-8.7,20.8-3,5.1-6.6,11.1-10.5,17.7Z"/>
      <path d="M700.3,813c-2.2-18-5.9-37.6-11.9-57.3-18.7,15.6-37.2,27.7-52,36.4,7.1,23.7,10.6,46.1,12.2,62.4,16.2-10.8,34.4-24.6,51.7-41.5Z"/>
      <path d="M558.7,899c6.4-2.3,12.8-4.7,19.1-7.3-1-5.1-2.1-10.2-3.5-15.3-.2-.9-.5-1.8-.7-2.7.3-.5-15.7,26.6-14.9,25.3Z"/>
      <path d="M515.7,1069.8c2.5-14.9,4.3-31.7,4.2-49.1,0-3.2-.1-6.3-.3-9.4-11,4.3-21.2,7.7-30,10.4-1.3.4-2.7.8-4.1,1.2.2-.4-14.8,25.1-24.8,41.9l55,5Z"/>
      <path d="M587.5,970.7c26.8-18.7,44.9-38.2,57-54.8,1.3-18.2,1.6-36.3.3-53.5-5.1,3.3-10,6.2-14.5,8.8-14.8,8.7-30.9,16.4-47.4,23.2,4.6,25.1,5.3,48.6,5,65.3,0,3.6-.2,7.3-.4,11Z"/>
      <path d="M516.4,1089.2"/>
      <path d="M520.2,1070.2l12.9,1.2c12.8-15,28.2-35.3,44.7-58.2,2-11.3,3.5-22.6,4.5-33.6-19.8,12.8-40,22.6-58.3,30,.2,3.7.3,7.4.3,11.2.1,17.6-1.7,34.5-4.2,49.5Z"/>
      <path d="M583.7,1004.9"/>
      <path d="M577.8,1013.1"/>
      <path d="M724.5,792.3c-.9,1.4-1.9,2.9-2.9,4.5,1-1.6,2-3.1,2.9-4.5Z"/>
      <path d="M439,947.5c-.5-5.7-1-11.1-1.4-16.2-8.7-16.3-16.5-32.3-23.5-48.1,0,.2-.2.3-.3.5-9,17.2-17.3,35.3-25.1,54.5,4.8,11.3,10.2,22.6,16.1,34,4.1,7.8,8.4,15.6,12.9,23.5,6.6-16.8,13.6-32.9,21.2-48.1Z"/>
      <path d="M396.3,1059c6-20.4,12.4-39.7,19.4-58-5.3-8.9-10.2-17.8-14.8-26.8-5.2-10.1-10.1-20.2-14.5-30.2-.6,1.7-1.3,3.3-1.9,5,2.3,42.4,6.9,87.5,10.6,109.9h1.2Z"/>
      <path d="M409.8,881.6c.7-1.2,1.3-2.4,2-3.7-4.8-11.2-9.1-22.3-13.1-33.4-1.3-3.6-2.5-7.2-3.7-10.8-6.5,16.2-11.9,38.3-11.9,69.7,0,6.9.1,14.2.3,21.8.9,2.3,1.9,4.7,2.8,7,7.3-17.8,15.1-34.6,23.6-50.7Z"/>
      <path d="M436.8,920.2c-2.3-38.8-.3-61.5,1.1-71.6.3-1.9.2-3.8-.2-5.7-7.3,11.2-14.3,22.9-20.9,35.2,6,13.9,12.7,27.9,20,42.1Z"/>
      <path d="M453.3,1044.3l-.3,1.2c-6.4-34.8-10.5-64.4-13.1-89.5-6.8,14.2-13.1,29-19.1,44.6,9.7,16.3,20.4,32.6,32.3,49l.3-5.3Z"/>
      <path d="M452.3,1064.1l.3-7.2c-12.5-17.1-23.8-34-34-50.9-6.4,16.9-12.3,34.7-17.8,53.5l51.4,4.6Z"/>
      <path d="M403,843c3.5,9.9,7.4,19.8,11.6,29.8,6.7-12.3,13.8-23.9,21.2-35.1-.2-.4-.5-.8-.7-1.1-4.3-6-11.4-16.2-18.2-27-1.6-2.6-3.2-5.2-4.7-7.9-3.7,6.4-9.2,14.5-14.3,25.8,1.7,5.2,3.4,10.3,5.3,15.5Z"/>
      <path d="M445.1,1060.7c-.4.9-.9,1.7-1.3,2.6l5,.4c2.3-4.1,3.9-6.9,3.9-6.9,0,0,62.1-104.6,79.2-132.7,15-24.7,150.8-240,154.6-253.1,5.1-17.9-24.3-25.1-24.3-25.1l-2,3.3s27.4,8.7,20.6,20.8c-75.3,133.9-194.5,307.8-235.8,390.7Z"/>
      <path d="M660.4,642s23.4.4,37.3,18.4c13.9,18,46.4,90.1,47.7,98.2,1.4,8.1.1,15.7-32.9,69.1-33.2,53.7-131.2,199-162.4,245.1l14.1,1.3c21.3-30.4,183-274.2,191-303.5,4-14.6-9.3-40.1-23.1-69.5-12-25.6-21.1-43.3-26.1-49.5-9.8-12.2-33.1-18.9-43.3-17.3-10.2,1.6-2.4,7.7-2.4,7.7Z"/>
      <g>
        <path d="M721.6,796.9c-5.4,6.2-10.9,12.2-16.6,17.8.3,2.4.5,4.8.8,7.2-.4.6,11.2-17.6,15.9-25Z"/>
        <path d="M649,859.6c1.3,15.8,1.3,32.4.4,49.1,3-3.8,39.9-61.1,52.4-80.6-.2-3.1-.5-6.2-.9-9.5-17.5,16.7-35.8,30.4-51.9,41Z"/>
        <path d="M701.9,828s0,0,0,0h0s0,0,0,0Z"/>
      </g>
      <path d="M490.1,923.6s.1-.1.3-.3c11.2-10.2,24.4-18,38.7-22.8,4.9-1.7,10.2-3.3,14.7-4.5l5.4-8.6s-33.8,11.6-41.4,16.7c-7.7,5.1-14,10.8-17.8,19.5Z"/>
      <path d="M726.3,328.1c-12.3-17.2-21.7-48.5-23.1-55.7-.7,5.2-3.3,31.4,23.1,55.7Z"/>
      <path d="M665.8,280c1.3,35.7,7.3,58.8,40.8,68.1-21-23.7-39.1-49.2-40.8-68.1Z"/>
      <path d="M366.5,1056.3l12,1.1c-4.6-26.9-14.5-100.3-4.3-186,5.8-48.7,37.1-82.3,37.1-82.3l-7.6-6.9c-9.2,12.6-29.6,37.5-37.3,78.6s-9.1,85.3-5.8,136.5c1.9,29,4.2,48,5.9,58.9Z"/>
      <path d="M670,985.9c-.9.4-1.5-.9-.7-1.4,10.5-5.8,24-11,37.4-14.5,3.2-.8,6.1-1.6,8.9-2.1,19.1-4.1,27-2,26.6,6.1s-3.4,29.4-3.4,29.4h-5.2s5.4-27.3,2-30c-6.5-5.1-41.5,2.5-65.6,12.6Z"/>
      <path d="M715.1,970.8s-28.8-47.8-59.7-34.3-23.7,36.7-23.7,36.7c0,0,18.9-32.7,30.1-31.7s26.5-.4,42.9,28.7l10.4.7Z"/>
      <path d="M617.1,994.3l-2.4,33.8c35.2,11.2,73.3,15.8,113.7,15.2l4.8-31.6c-41.5,2.9-80.3-2.4-116.1-17.5Z"/>
      <path d="M739.9,1004c1.5-.3,2.8,1,2.6,2.5-2.2,13.7-11,67.8-13.1,81l.7,1.6,8.2.7,12.3-86.4c.6-4.1-2.9-7.8-7-7.3-41.2,4.7-82.8.1-122.8-12.5l-4.3,6.9c57.7,17.2,95.6,19.2,123.4,13.4Z"/>
      <path d="M603.3,1077.7c2.9-18.1,5.1-73.9,5.1-73.9l-9.8,12.3-5.8,60.7,10.5.9Z"/>
      <polygon points="372.9 1056.9 363.5 969.2 363.7 918.6 372.1 865.9 386.7 815.1 407.6 783.8 403.8 782.3 396.6 777.7 342.8 797.5 306.7 820.9 287.3 852.4 254.8 935.1 236.7 972.2 217.4 1010.2 199.5 1041.3 372.9 1056.9"/>
      <polygon points="598 1077.2 602.1 1012.3 557.9 1073.6 598 1077.2"/>
      <polygon points="697.2 953.3 710.1 968.8 732.5 968.7 738.9 972.2 736.9 999 733.6 1003.3 745.5 1001.9 745.4 1013.1 732.1 1089.3 940.2 1108 934.1 1067.3 918.3 1015.6 907.3 982 892.9 935.1 891.9 895 881.6 864.3 853.8 832 761.7 769.7 747.4 774 711.9 836.9 648 937.3 644.3 945.6 670.7 938.2 697.2 953.3"/>
      <path d="M876.6,862.9c7.8,11.5,10.8,42,12.8,62.2.8,8.5,1.6,15.9,2.5,20.9.9,5,4.6,15.5,9.7,30,12.3,34.8,32.2,91.3,34.2,131.6l9,.8c-1.8-41.9-22.2-99.9-34.8-135.5-4.8-13.6-8.6-24.3-9.4-28.6-.8-4.6-1.6-11.8-2.4-20.1-2.3-23.6-5.2-53-14.4-66.3-7.1-10.3-35.4-32.8-57.5-48.9-30.6-22.3-57.9-39.1-72.9-45l-3.3,8.4c31.3,12.4,115,74,126.3,90.6Z"/>
      <g>
        <path d="M619.2,796.6c4-2.1,8-4.3,11.9-6.5-.9-2.9-1.9-5.8-2.9-8.7-3.5,5.9-9,15.2-9,15.2Z"/>
        <path d="M644.2,855.7c-1.6-15.9-4.8-37.9-11.8-61.2-5.7,3.2-11.5,6.3-17.5,9.3,0,0-24.6,41.6-38.1,64.6.7,2.3,1.3,4.6,1.9,6.9,1.3,4.9,2.4,9.8,3.4,14.7,16-6.7,31.6-14.2,46-22.6,5-2.9,10.5-6.3,16.3-10,0-.6-.1-1.1-.2-1.7Z"/>
      </g>
      <path d="M487.9,741.3c-10.7,1.7-18.2,42.7-18.8,51-.5,6.8,0,24.2.3,25.6.9,8,1.9,16.4,2.8,25.2,6.3,60,11.2,136.9,6.5,157.4,0,0,0,.6.2,1.4l4.9.4c.6-3.9,1.1-9.6,1.6-18,1.3-21.2-.9-70.9-5.1-119.9-1.6-18.5-3.4-37-5-53.8-1.1-11.3-.3-22.8,2.4-33.9,2.9-12,6.9-26.3,10.5-29.7,5.8-5.5,32.9,6.6,32.9,6.6l3.4-3.4s-25.2-10.8-36.8-8.9Z"/>
      <path d="M597.7,817.8c-.2-1.4-.3-2.7-.4-3.4-.3-3.8-14.9-39.4-23.6-39.1-3.6.1,11.2,28.8,15.2,37.2,2.1,4.5,3.8,7.6,5,9.6l3.7-4.4Z"/>
      <path class="brow brow--l" d="M384.9,383.5c-9.9-8.6-23.5-15.9-36.5-19.6-17.3-4.9-33-3.3-45.2,4.7-4.9,3.2-6.4,9.2-3.5,14,.6,1,1.8,2.1,3.1,2.3,0,0,.1,0,.2,0,.7,0,1.2-.1,1.7-.5,18.8-16.6,52.1-13.6,75.8,6.7.6.5,1.2,1,1.8.9.7,0,1.1-.5,1.8-1.2,1.2-1.3,2.6-5.8.9-7.3Z"/>
      <g>
        <path class="contour" d="M322.9,359c0-1.4.1-2.8.2-4.1.2-2.7.5-5.5.8-8.4l-3.6.2c-.8-.4-1.7-.5-2.5.1h-2.3c-.5,3.2-.8,6.2-1.1,9.1,0,0,0,0,0,0,0,.2,0,.4,0,.6,0,.2,0,.4,0,.5-.1,1.3-.2,2.6-.3,3.8,2.9-.9,5.8-1.5,8.9-1.8Z"/>
        <!-- Brücke in der linken Gesichtskontur: wächst nur, wenn die linke Braue hochgeht und die Lücke freilegt -->
        <path class="contour fx bridge" d="M314.3,356L323.5,356L323.3,382L314.6,382Z"/>
        <path class="contour" d="M330.9,405.6c-3.8-6.5-6.3-14.9-7.5-24.7,0-1.1-.2-2.1-.3-3.1-3.1.8-5.9,1.8-8.6,3.2.3,2,.7,4,1.1,6.1,1.6,8.8,2.6,16.2,7.2,22.6-4.3,24.7-1.7,54.3,6.1,75.6l8.3-.6c-9.8-33-10-54.2-6.3-79Z"/>
      </g>
      <!-- Zusatz-Elemente für Gesichtsausdrücke (standardmäßig unsichtbar) -->
      <g class="fxlayer">
        <g transform="translate(350 486)"><path class="fx tear tear--l" d="M0,-30C10,-12 19,0 19,12A19,19 0 1 1 -19,12C-19,0 -10,-12 0,-30Z"/></g>
        <g transform="translate(500 506)"><path class="fx tear tear--r" d="M0,-30C10,-12 19,0 19,12A19,19 0 1 1 -19,12C-19,0 -10,-12 0,-30Z"/></g>
        <g transform="translate(350 486)"><path class="fx tear tear--l2" d="M0,-30C10,-12 19,0 19,12A19,19 0 1 1 -19,12C-19,0 -10,-12 0,-30Z"/></g>
        <g transform="translate(500 506)"><path class="fx tear tear--r2" d="M0,-30C10,-12 19,0 19,12A19,19 0 1 1 -19,12C-19,0 -10,-12 0,-30Z"/></g>
        <g transform="translate(566 410) rotate(12)"><path class="fx sweat" d="M0,-26C9,-10 16,0 16,10A16,16 0 1 1 -16,10C-16,0 -9,-10 0,-26Z"/></g>
      </g>
    </g>
  </g>
  <circle class="st0" cx="532.8" cy="532.8" r="523.3"/>
</svg>`;

  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const rand = (a, b) => a + Math.random() * (b - a);

  // Wie weit das Oberlid nach unten fährt (SVG-Einheiten)
  const LID_DROP = 66;   // nur rechtes Oberlid; die linke Augenbraue bleibt stehen

  function blink(svg, speed = 1) {
    if (svg.dataset.mood) return 0;                   // während eines Ausdrucks nicht blinzeln
    const d = rand(150, 230) / speed;                 // Dauer variiert leicht
    const opts = { duration: d, easing: 'cubic-bezier(.4,0,.3,1)' };
    const offs = [0, .42, .58, 1];                    // schnell zu, kurz halten, auf
    svg.querySelectorAll('.pupil').forEach(p =>
      p.animate([{ transform:'scaleY(1)' }, { transform:'scaleY(.04)' }, { transform:'scaleY(.04)' }, { transform:'scaleY(1)' }]
        .map((k, i) => ({ ...k, offset: offs[i] })), opts));
    svg.querySelectorAll('.lid--r').forEach(l => {
      const y = LID_DROP;
      l.animate([{ transform:'translateY(0)' }, { transform:`translateY(${y}px)` }, { transform:`translateY(${y}px)` }, { transform:'translateY(0)' }]
        .map((k, i) => ({ ...k, offset: offs[i] })), opts);
    });
    return d;
  }

  /* Grundbewegung – läuft dauerhaft auf der Gruppe, die die ganze Figur enthält.
     Alle Ausdrücke animieren nur einzelne Teile darin, deshalb überlagern sich beide sauber.
     Zwei Schichten mit krummen Laufzeiten (additiv), damit es nie mechanisch wirkt. */
  function idle(svg) {
    const fig = svg.querySelector('.st1 > g'); if (!fig) return;
    fig.classList.add('idle');
    const phase = () => -rand(0, 20000);              // jede Instanz startet woanders im Zyklus
    fig.animate([                                     // leichtes Neigen & Wiegen
      { transform: 'translate(0px,0px) rotate(0deg)' },
      { transform: 'translate(-3px,0px) rotate(-1.1deg)', offset: .3 },
      { transform: 'translate(2px,-1px) rotate(.7deg)', offset: .62 },
      { transform: 'translate(-1px,0px) rotate(-.3deg)', offset: .85 },
      { transform: 'translate(0px,0px) rotate(0deg)' },
    ], { duration: 15000, iterations: Infinity, easing: 'ease-in-out', delay: phase(), composite: 'add' });
    fig.animate([                                     // Atmen
      { transform: 'translateY(0px)' }, { transform: 'translateY(-5px)' }, { transform: 'translateY(0px)' },
    ], { duration: 7000, iterations: Infinity, easing: 'ease-in-out', delay: phase(), composite: 'add' });
  }

  // Unregelmäßig: meist 2–6 s Pause, manchmal Doppel-Blinzeln, selten lange Pause
  function schedule(svg) {
    const r = Math.random();
    const wait = r < .12 ? rand(6000, 9000) : rand(1800, 5500);
    setTimeout(() => {
      const d = blink(svg);
      if (Math.random() < .22) setTimeout(() => blink(svg, 1.15), d + rand(90, 160));
      schedule(svg);
    }, wait);
  }

  const hosts = document.querySelectorAll('[data-logo]');
  hosts.forEach(host => {
    host.insertAdjacentHTML('beforeend', SVG);
    const svg = host.querySelector('svg');
    // Brauen nach oben in der Zeichenreihenfolge, damit ihr weißer Rand die Haare überdecken kann
    svg.querySelectorAll('.brow').forEach(b => b.parentNode.appendChild(b));
    // linke Gesichtskontur wieder darüber, damit der weiße Rand der linken Braue sie nicht anschneidet
    svg.querySelectorAll('.contour').forEach(c => { const g = svg.querySelector('.st1 > g'); g.appendChild(c); });
    if (!reduce) idle(svg);
    if (!reduce) setTimeout(() => schedule(svg), rand(200, 2500));
    host.addEventListener('mouseenter', () => blink(svg));
  });


  /* ---------- Gesichtsausdrücke ----------
     Alles läuft über Formveränderung – keine Transparenz:
     · Brauen, Lider, Pupillen: verschieben / drehen / stauchen
     · Mund: echtes Morphing der Kontur (Punkte werden interpoliert)
     · Neue Formen (Tränen, Schweiß, Denkblasen) wachsen aus Größe 0 heraus und schrumpfen wieder weg
     T(x, y, rot, sx, sy) – Werte in SVG-Einheiten bzw. Grad. */
  const T = (x = 0, y = 0, a = 0, sx = 1, sy = sx) => `translate(${x}px,${y}px) rotate(${a}deg) scale(${sx},${sy})`;
  const N = T();
  const ZERO = T(0, 0, 0, 0);
  const HOLD = 2600, IN = .14, OUT = .86;           // Anteil der Gesamtdauer für Rein/Raus
  const EASE = 'cubic-bezier(.3,0,.2,1)';

  /* --- Morph-Werkzeug für den Mund --- */
  const NPTS = 120;
  const area = p => p.reduce((s, [x, y], i) => { const [x2, y2] = p[(i + 1) % p.length]; return s + x * y2 - x2 * y; }, 0) / 2;
  function resample(poly, n = NPTS) {               // geschlossenes Polygon gleichmäßig nach Bogenlänge abtasten
    const seg = poly.map((p, i) => { const q = poly[(i + 1) % poly.length]; return Math.hypot(q[0] - p[0], q[1] - p[1]); });
    const L = seg.reduce((a, b) => a + b, 0); const out = []; let i = 0, acc = 0;
    for (let k = 0; k < n; k++) {
      const d = L * k / n;
      while (acc + seg[i] < d) { acc += seg[i]; i++; }
      const t = seg[i] ? (d - acc) / seg[i] : 0, p = poly[i], q = poly[(i + 1) % poly.length];
      out.push([p[0] + (q[0] - p[0]) * t, p[1] + (q[1] - p[1]) * t]);
    }
    return out;
  }
  function samplePath(el) {
    const L = el.getTotalLength();
    return Array.from({ length: NPTS }, (_, i) => { const p = el.getPointAtLength(L * i / NPTS); return [p.x, p.y]; });
  }
  function align(src, dst) {                          // gleiche Laufrichtung + bester Startpunkt → kein Verdrehen
    if (Math.sign(area(src)) !== Math.sign(area(dst))) dst = dst.slice().reverse();
    let best = 0, bestD = Infinity;
    for (let o = 0; o < dst.length; o++) {
      let d = 0; for (let i = 0; i < src.length; i++) { const a = src[i], b = dst[(i + o) % dst.length]; d += (a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2; }
      if (d < bestD) { bestD = d; best = o; }
    }
    return src.map((_, i) => dst[(i + best) % dst.length]);
  }
  const toD = p => 'M' + p.map(([x, y]) => x.toFixed(1) + ',' + y.toFixed(1)).join('L') + 'Z';
  const bbox = p => { const xs = p.map(q => q[0]), ys = p.map(q => q[1]);
    return { cx: (Math.min(...xs) + Math.max(...xs)) / 2, cy: (Math.min(...ys) + Math.max(...ys)) / 2 }; };
  // Punkte transformieren: spiegeln/skalieren/drehen um die Mund-Mitte, dann verschieben
  const xform = (p, { sx = 1, sy = 1, a = 0, dx = 0, dy = 0 } = {}) => {
    const { cx, cy } = bbox(p), r = a * Math.PI / 180, c = Math.cos(r), s = Math.sin(r);
    return p.map(([x, y]) => { const u = (x - cx) * sx, v = (y - cy) * sy; return [cx + u * c - v * s + dx, cy + u * s + v * c + dy]; });
  };
  const ellipse = (cx, cy, rx, ry) => Array.from({ length: NPTS }, (_, i) => { const t = i / NPTS * Math.PI * 2; return [cx + rx * Math.cos(t), cy + ry * Math.sin(t)]; });
  // Strich als Fläche: Mittellinie f(t) mit Breite w(t)
  function strokeShape(f, w, n = 60) {
    const top = [], bot = [];
    for (let i = 0; i <= n; i++) {
      const t = i / n, [x, y] = f(t), [x2, y2] = f(Math.min(1, t + .01)), [x0, y0] = f(Math.max(0, t - .01));
      let nx = -(y2 - y0), ny = x2 - x0; const l = Math.hypot(nx, ny) || 1; nx /= l; ny /= l;
      const h = w(t) / 2; top.push([x + nx * h, y + ny * h]); bot.push([x - nx * h, y - ny * h]);
    }
    return resample(top.concat(bot.reverse()));
  }
  const taper = (m) => t => m * Math.sin(Math.PI * t) ** .6 + 1.2;

  // Zielformen für den Mund (bekommen die Originalpunkte, liefern neue Punkte)
  const MOUTH = {
    erstaunt:     () => ellipse(432, 588, 15, 21),                                        // Lächeln zieht sich zum „O“ zusammen
    wuetend:      p => xform(p, { sx: .8, sy: -1.1, dx: 4, dy: 8 }),                       // umgedreht, enger
    nachdenklich: () => strokeShape(t => [428 + 44 * t, 586 - 9 * t + 3 * Math.sin(Math.PI * t)], t => 5.5 * Math.sin(Math.PI * t) ** .4 + 1.5), // „Hmm“: kurz, flach, in den Mundwinkel geschoben
    aengstlich:   () => strokeShape(t => [404 + 62 * t, 590 + 4.5 * Math.sin(t * Math.PI * 3)], taper(5)), // Wellenlinie
    weinend:      () => strokeShape(t => [400 + 66 * t, 600 - 15 * Math.sin(Math.PI * t) + 2 * t], t => 8 * Math.sin(Math.PI * t) ** .5 + 1.5), // zitternder Bogen nach unten
  };

  // Geschlossene, zusammengekniffene Augen (Weinen): Pupille morpht zu einem Bogen
  const closedArc = (x0, x1, base, hgt, w) => () => strokeShape(t => [x0 + (x1 - x0) * t, base - hgt * Math.sin(Math.PI * t)], t => w * Math.sin(Math.PI * t) ** .5 + 2);
  // Form auf ihre Mittellinie zusammenziehen → Strich wird dünner, bis er weg ist
  const thinOut = p => mid(mid(mid(p)));            // mehrfach, damit wirklich nichts übrig bleibt
  const mid = p => p.map((a, i) => {
    let best = null, bd = Infinity;
    p.forEach((b, j) => { const k = Math.abs(i - j), gap = Math.min(k, p.length - k);
      if (gap > p.length / 8) { const d = (a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2; if (d < bd) { bd = d; best = b; } } });
    return [(a[0] + best[0]) / 2, (a[1] + best[1]) / 2];
  });
  thinOut.vanish = true;
  const EYES = {
    erstaunt: { '.chin': thinOut },
    weinend: { '.eye--r': closedArc(450, 512, 462, 16, 9), '.eye--l': closedArc(340, 384, 464, 12, 8), '.lid--r': thinOut, '.chin': thinOut },
  };

  function morph(el, target, dur) {
    const orig = el.dataset.d || (el.dataset.d = el.getAttribute('d'));
    el.setAttribute('d', orig);
    const src = samplePath(el);
    const dst = align(src, resample(target(src)));
    const t0 = performance.now(), ease = t => t < .5 ? 4 * t * t * t : 1 - (-2 * t + 2) ** 3 / 2;
    cancelAnimationFrame(el._raf);
    const step = now => {
      const k = (now - t0) / dur;
      if (k >= 1) { el.setAttribute('d', orig); return; }
      const m = k < IN ? ease(k / IN) : k > OUT ? 1 - ease((k - OUT) / (1 - OUT)) : 1;
      if (m === 1 && target.vanish) { el.setAttribute('d', 'M0,0Z'); el._raf = requestAnimationFrame(step); return; } // ganz dünn = weg
      el.setAttribute('d', toD(src.map(([x, y], i) => [x + (dst[i][0] - x) * m, y + (dst[i][1] - y) * m])));
      el._raf = requestAnimationFrame(step);
    };
    el._raf = requestAnimationFrame(step);
  }

  const MOODS = {
    erstaunt: {
      '.brow--r': { t: T(0, -30, -4) }, '.brow--l': { t: T(0, -26, 4) },
      '.lid--r': { t: T(0, -16) },
      '.pupil': { t: T(0, 0, 0, 1.06, 1.12) },
      '.dimple': { t: ZERO },
      halo: '.brow',
      '.bridge': { t: N },
    },
    wuetend: {
      '.brow--r': { t: T(4, 16, -16) }, '.brow--l': { t: T(-2, 14, 18) },
      '.lid--r': { t: T(0, 26) },
      '.pupil': { t: T(0, 4, 0, .92, .78) },
      '.dimple': { t: ZERO },
      shake: true,
    },
    nachdenklich: {
      '.brow--r': { t: T(0, -24, -10) }, '.brow--l': { t: T(0, -4, 9) },
      '.lid--r': { t: T(0, -10) },
      '.dimple': { t: ZERO },
      ponder: true, halo: '.brow--r',
    },
    aengstlich: {
      '.brow--r': { t: T(0, -18, 14) }, '.brow--l': { t: T(0, -14, -16) }, '.bridge': { t: N },
      '.lid--r': { t: T(0, -12) },
      '.pupil': { t: T(0, -4, 0, .72) },
      '.dimple': { t: ZERO },
      '.sweat': { t: T(0, 26), from: ZERO, delay: 300 },
      tremble: true,
    },
    weinend: {
      '.brow--r': { t: T(0, -12, 10) }, '.brow--l': { t: T(0, -10, -11) }, '.bridge': { t: N },
      '.lowlid': { t: T(0, 0, 0, .2, 0) },           // Unterlid zieht sich in den Augenbogen zurück
      '.dimple': { t: ZERO },
      tears: true,
    },
  };

  function pose(el, cfg, dur) {
    const rest = cfg.from || (el.classList.contains('fx') ? ZERO : N);
    const t = cfg.t || N, delay = cfg.delay || 0;
    return el.animate([
      { transform: rest, offset: 0 }, { transform: t, offset: IN }, { transform: t, offset: OUT }, { transform: rest, offset: 1 },
    ], { duration: dur - delay, delay, easing: EASE, fill: 'backwards' });
  }

  function express(svg, name) {
    const m = MOODS[name]; if (!m) return;
    svg.getAnimations({ subtree: true }).forEach(a => { if (!a.effect.target.classList.contains('idle')) a.cancel(); }); // Grundbewegung läuft weiter
    svg.dataset.mood = name;
    const dur = HOLD;
    for (const [sel, cfg] of Object.entries(m)) {
      if (typeof cfg !== 'object') continue;
      svg.querySelectorAll(sel).forEach(el => pose(el, cfg, dur));
    }
    svg.querySelectorAll('.mouth').forEach(el => morph(el, MOUTH[name], dur));
    Object.entries(EYES[name] || {}).forEach(([sel, fn]) => svg.querySelectorAll(sel).forEach(el => morph(el, fn, dur)));
    // Wütend: kurzes Beben der Brauen
    if (m.shake) svg.querySelectorAll('.brow, .lid--r').forEach(el =>
      el.animate([{ transform: 'translateX(0)' }, { transform: 'translateX(-3px)' }, { transform: 'translateX(3px)' }, { transform: 'translateX(0)' }],
        { duration: 120, iterations: 12, delay: 380, composite: 'add' }));
    // Weißer Abstand wächst um die Brauen, solange sie oben sind
    if (m.halo) svg.querySelectorAll(m.halo).forEach(el => el.animate([
      { strokeWidth: 0 }, { strokeWidth: 16, offset: IN }, { strokeWidth: 16, offset: OUT }, { strokeWidth: 0 }],
      { duration: HOLD, easing: EASE }));
    // Nachdenklich: rechte Braue wippt grübelnd hoch und runter, linke zieht sich im Gegentakt zusammen
    if (m.ponder) {
      const o = { duration: 1700, delay: 420, easing: 'ease-in-out', composite: 'add' };
      svg.querySelectorAll('.brow--r').forEach(el => el.animate([
        { transform: T() }, { transform: T(0, -9, -4), offset: .25 }, { transform: T(0, 2, 2), offset: .5 },
        { transform: T(0, -8, -3), offset: .75 }, { transform: T() }], o));
      svg.querySelectorAll('.brow--l').forEach(el => el.animate([
        { transform: T() }, { transform: T(0, 3, 4), offset: .25 }, { transform: T(0, -2, -2), offset: .5 },
        { transform: T(0, 3, 4), offset: .75 }, { transform: T() }], o));
      svg.querySelectorAll('.lid--r').forEach(el => el.animate([
        { transform: T() }, { transform: T(0, -5), offset: .25 }, { transform: T(0, 1), offset: .5 },
        { transform: T(0, -4), offset: .75 }, { transform: T() }], o));
    }
    // Ängstlich: Pupillen zittern
    if (m.tremble) svg.querySelectorAll('.pupil').forEach(el =>
      el.animate([{ transform: 'translate(0,0)' }, { transform: 'translate(-2px,1px)' }, { transform: 'translate(2px,-1px)' }, { transform: 'translate(0,0)' }],
        { duration: 90, iterations: 22, delay: 300, composite: 'add' }));
    // Weinend: Tränen wachsen aus dem Auge, kullern runter und schrumpfen weg
    if (m.tears) [['.tear--l', 380], ['.tear--r', 560], ['.tear--l2', 1150], ['.tear--r2', 1330]].forEach(([sel, d]) =>
      svg.querySelectorAll(sel).forEach(el => el.animate([
        { transform: T(0, 0, 0, 0) },
        { transform: T(0, 0, 0, 1), offset: .22 },
        { transform: T(0, 110, 0, .9, 1.1), offset: .82 },
        { transform: T(0, 130, 0, 0) },
      ], { duration: 1100, delay: d, easing: 'cubic-bezier(.5,0,.8,.6)', fill: 'backwards' })));
    setTimeout(() => { if (svg.dataset.mood === name) delete svg.dataset.mood; }, dur + 20);
  }

  /* ---------- Auslösen ----------
     Klick irgendwo auf die Seite (nicht auf Links, Buttons, Menü, Cookie-Banner) spielt einen zufälligen Ausdruck.
     Ziehen zum Sprühen zählt nicht als Klick. */
  const NAMES = Object.keys(MOODS);
  let lastMood = null;
  function randomMood() {
    const pool = NAMES.filter(n => n !== lastMood);
    lastMood = pool[Math.floor(Math.random() * pool.length)];
    hosts.forEach(h => { const s = h.querySelector('svg'); if (s) express(s, lastMood); });
    return lastMood;
  }
  let down = null;
  window.addEventListener('pointerdown', e => { down = { x: e.clientX, y: e.clientY }; }, { passive: true });
  window.addEventListener('click', e => {
    if (document.body.classList.contains('menu-open')) return;
    if (e.target.closest && e.target.closest('a, button, input, textarea, select, label, .menu, .consent, .nav')) return;
    if (down && Math.hypot(e.clientX - down.x, e.clientY - down.y) > 8) return;   // war Sprühen, kein Klick
    randomMood();
  });

  /* ---------- Scroll: Logo fährt verkleinert nach oben in die Mitte und bleibt dort ----------
     Start = Platzhalter #logoSlot auf der Stage (Lage bei Scroll 0), Ziel = klein oben mittig auf Höhe der Navigation.
     Dazwischen wird nach Scrollfortschritt überblendet (nur Position und Größe, per transform). */
  const float = document.getElementById('logoFloat'), slot = document.getElementById('logoSlot');
  if (float && slot) {
    const nav = document.getElementById('menuBtn'), menuEl = document.getElementById('menu'), navBar = document.querySelector('.nav');
    const ease = t => t < .5 ? 2 * t * t : 1 - (-2 * t + 2) ** 2 / 2;
    let baseW = 0, ticking = false;
    function place() {
      ticking = false;
      const s = slot.getBoundingClientRect();
      if (!s.width) return;
      if (Math.abs(baseW - s.width) > .5) { baseW = s.width; float.style.width = baseW + 'px'; }
      const mobile = innerWidth <= 760;
      const endW = mobile ? 66 : Math.max(88, Math.min(132, innerWidth * .068));
      const gutter = parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--gutter')) || (innerWidth * 148 / 3840);
      const nb = nav ? nav.getBoundingClientRect() : { top: 24, height: 40 };
      const navLeft = navBar ? navBar.getBoundingClientRect().left : innerWidth;
      const endX = Math.max(mobile ? 20 : gutter, Math.min((innerWidth - endW) / 2, navLeft - endW - 16));   // oben mittig – weicht nach links aus, wenn die Navigation sonst überlappt (schmale Bildschirme)
      const endY = Math.max(12, nb.top + nb.height / 2 - endW * (532.8 / 1065.5));   // Kreismitte auf Höhe der Navigation, mit Abstand zum Rand
      const dist = Math.max(1, innerHeight * .6);                       // so viel Scrollweg bis ganz oben
      const inMenu = !!(menuEl && menuEl.classList.contains('is-content'));   // Menü offen: immer oben mittig
      float.classList.toggle('is-menu', inMenu);
      const p = inMenu ? 1 : ease(Math.min(1, Math.max(0, scrollY / dist)));
      const sx = s.left + scrollX, sy = s.top + scrollY;               // Startlage wie ganz oben auf der Seite – Logo bleibt im Bild und fährt direkt hoch
      const x = sx + (endX - sx) * p, y = sy + (endY - sy) * p, w = s.width + (endW - s.width) * p;
      float.style.transform = `translate(${x.toFixed(2)}px,${y.toFixed(2)}px) scale(${(w / baseW).toFixed(4)})`;
      float.classList.add('is-placed');
      float.classList.toggle('is-docked', p >= 1);
    }
    const req = () => { if (!ticking) { ticking = true; requestAnimationFrame(place); } };
    addEventListener('scroll', req, { passive: true });
    addEventListener('resize', req);
    if (window.ResizeObserver) new ResizeObserver(req).observe(slot);
    if (menuEl && window.MutationObserver) new MutationObserver(req).observe(menuEl, { attributes: true, attributeFilter: ['class'] });
    place();
    // angedockt: Klick aufs Logo bringt nach oben
    float.addEventListener('click', e => { if (float.classList.contains('is-docked') && !float.classList.contains('is-menu')) { e.stopPropagation(); scrollTo({ top: 0, behavior: 'smooth' }); } });
  }
  window.thomasLogo = { express: name => hosts.forEach(h => express(h.querySelector('svg'), name)), random: randomMood, moods: NAMES };
})();
